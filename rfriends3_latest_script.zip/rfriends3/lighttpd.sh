#!/bin/sh
# Lighttpd  2026/07/08

CONF_FILE="/etc/lighttpd/lighttpd.conf"

if [ ! -f "$CONF_FILE" ]; then
    echo "Error: $CONF_FILE が見つかりません。Lighttpdがインストールされていないか、パスが異なります。"
    exit 1
fi

if [ "$(id -u)" -ne 0 ]; then
    echo "Error: このスクリプトの実行には管理者権限が必要です。 sudo をつけて実行してください。"
    exit 1
fi

cp "$CONF_FILE" "${CONF_FILE}.bak"

if grep -qE "^[[:space:]]*server\.stream-response-body[[:space:]]*=[[:space:]]*1" "$CONF_FILE"; then
    echo "設定はすでに有効（= 1）になっています。書き換えは不要です。"
    exit 0
fi

if grep -qE "server\.stream-response-body" "$CONF_FILE"; then
    sed -i -E 's/([#[:space:]]*)(server\.stream-response-body[[:space:]]*=[[:space:]]*)[0-9]/server.stream-response-body = 1/' "$CONF_FILE"
    echo "既存の設定を「1（有効）」に更新しました。"
else
    echo "" >> "$CONF_FILE"
    echo "# Added for audio streaming support" >> "$CONF_FILE"
    echo "server.stream-response-body = 1" >> "$CONF_FILE"
    echo "設定ファイルに項目を追加しました。"
fi

echo "Webサーバーを再起動しています..."
if command -v systemctl >/dev/null 2>&1; then
    systemctl restart lighttpd
else
    service lighttpd restart
fi

echo "完了しました"
exit 0
