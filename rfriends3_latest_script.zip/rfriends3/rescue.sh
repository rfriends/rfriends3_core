#!/bin/sh
# 録音ツール

echo
echo このファイルはメンテナンスされていません。
echo
exit

cd `dirname $0`
base=`pwd`/

ex=rescue
php ${base}script/$ex.php

echo done
