<?php
 function ht_sub_lnx() { global $ht_jump_btn1_label; $ht_jump_btn1_label = "選択"; $mnus = array( 'audio選択(ALSA)','audio選択(PulseAudio)' ); $n = 1; $lists = array(); foreach($mnus as $mnu) { $lists[] = array('title'=>$mnu,'val'=>$n); $n++; } $opt = array( "title" => 'Linux専用メニュー', "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "" ); ht_ask_list($lists,$opt); } function ht_sub_lnx_s($val) { global $ht_jump_no; global $ht_jump_btn1_label; global $ht_jump_val2; global $sound_mode; $ht_jump_val2 = $val; switch($val) { case 1: echo_msg(2,"audio card(ALSA)の選択をおこないます。"); echo_msg(2,""); $ht_jump_no = "010803"; $ht_jump_btn1_label = "選択"; $cards = rf_alsa_list(); $main_cat = rf_alsa_cat_cards($cards); if ($main_cat == array()) { echo_msg(2,"サウンドカードがみつかりません。"); return false; } $sub_cat = rf_alsa_cat_mixer($cards); if ($sub_cat == array()) { echo_msg(2,"オーディオミキサーがみつかりません。"); return false; } $now_asound = rf_get_alsa(); if ($now_asound !== false) { $card = $now_asound[0]; $mixer = $now_asound[1]; echo_msg(2,"現在、以下が選択されています。"); echo_msg(2,"card  : $card"); echo_msg(2,"mixer : $mixer"); echo_msg(2,""); } $json_main = json_encode($main_cat); $json_sub = json_encode($sub_cat); echo <<<EOF
        <form action="menu_ss.html" method="get">
        Card :</br>
              <select id="main-cat-sel" name=val style="width:200px">
                <option disabled selected>選択してください</option>
              </select>
        
        <p>&nbsp;</p>
        
        Mixer:</br>
              <select id="sub-cat-sel" name=sel style="width:200px">
                <option disabled selected>選択してください</option>
              </select>
        <INPUT type='hidden' name='subno' value='010803'>
        <INPUT type='hidden' name='val2'   value='1'>
        
        <p><br><button class='btn_ex' type='submit'>選択</button></p>
        </form>    
        
        <script>
        rf_pulldown_menu($json_main,$json_sub);
        
        function rf_pulldown_menu(json_main,json_sub){
        
        let main_cat = json_main;
        let sub_cat  = json_sub;
        
        //console.log(main_cat);
        //console.log(sub_cat);
        
        const maincatsel = document.getElementById('main-cat-sel');
        const subcatsel = document.getElementById('sub-cat-sel');
        
        // main
        main_cat.forEach(category => {
          const option = document.createElement('option');
          option.textContent = category;
        
          maincatsel.appendChild(option);    
        });
        
        // sub
        maincatsel.addEventListener('input', () => {
        
          // reset sub
          const options = document.querySelectorAll('#sub-cat-sel > option');
          options.forEach(option => {
            option.remove();
          });
        
          // sub
          //const firstSelect = document.createElement('option');
          //firstSelect.textContent = '選択してください';
          //subcatsel.appendChild(firstSelect);
        
          // select sub
          sub_cat.forEach(subCategory => {
            if (maincatsel.value == subCategory.category) {
              const option = document.createElement('option');
              option.textContent = subCategory.name;
              
              subcatsel.appendChild(option);
            }
          });
        });
        }
        </script>
        EOF;
break; case 2: echo "<p>audio card(Pulse Audio)の選択をおこないます。</p>"; echo "<p>&nbsp;</p>"; if ($sound_mode != 2) { echo "<p>Pulse Audio が設定されていません。</p>"; echo "<p>設定 - パラメータ でpulseaudio=1</p>"; echo "<p>&nbsp;</p>"; break; } $ht_jump_no = "010803"; $ht_jump_btn1_label = "選択"; $cards = rf_pulseaudio_list(); if (count_73($cards) <= 0) { echo "<p>サウンドカードがみつかりません。</p>"; break; } $cdat = rf_pulseaudio_now(); if ($cdat === false) { echo "<p>現在、選択されていません。</p>"; echo "<p>&nbsp;</p>"; } else { echo "<p>現在、$cdat[0] : $cdat[1] が選択されています。</p>"; echo "<p>&nbsp;</p>"; } $lists = array(); foreach($cards as $card) { $cdat = explode(',',$card); $lists[] = array('title'=>"$cdat[0] : $cdat[1]",'val'=>$cdat[0]); } $opt = array( "title" => "audio card一覧", "mode" => 1, "multi" => 0, "confirm" => 0, "ht_selid" => "" ); ht_ask_list($lists,$opt); break; default: return; break; } } function ht_sub_lnx_ss($val,$val2,$sel) { global $scrdir; global $htmldir; global $alsa_mixer; $rst = 1; switch($val) { case 1: echo_msg(2,"audio card(ALSA)"); echo_msg(2,""); $card = $val2; $mixer = $sel; $data[0] = "$card"; $data[1] = "$mixer"; $ret = rf_put_alsa($data); if ($ret === false) { echo_msg(2,"変更に失敗しました。"); break; } $n_name = rf_alsa_name($card); if ($n_name === false) { $n_name = "unknown"; } echo_msg(2,"card  : $card"); echo_msg(2,"mixer : $mixer"); echo_msg(2,"に変更しました。"); echo_msg(2,""); $rst = 0; break; case 2: echo "<p>audio card(Pulse audio)設定</p>"; echo "<p>&nbsp;</p>"; $rst = 0; $cards = rf_pulseaudio_list(); if (count_73($cards) <= 0) { echo "<p>サウンドカードがみつかりません。</p>"; break; } foreach($cards as $card) { $cdat = explode(',',$card); if ($cdat[0] == $val2) { break; } } if ($cdat[0] != $val2) { echo "<p>>pulseaudio 設定エラー</p>"; break; } $ret = rf_pulseaudio_run($cdat[0]); if ($ret === false) { echo "<p>pulseaudio run コマンドエラー</p>"; break; } echo "<p>&nbsp;</p>"; echo "<p>audio card(Pulse audio)を</p>"; echo "<p>$cdat[0] : $cdat[1]</p>"; echo "<p>に変更しました。</p>"; echo "<p>&nbsp;</p>"; break; default: $rst = 0; break; } return $rst; } ?>
