<?php
 function ht_exaudio_test($url,$token,$partialkey) { $dat = rf_device_info(); $app = $dat[0]; $ver = $dat[1]; $user = $dat[2]; $dev = $dat[3]; $con = $dat[4]; $app = "pc_html5"; $ver = "0.0.1"; $user = "dummy_user"; $dev = "pc"; $referer = "https://radiko.jp/"; $opts = array( 'https' => array( 'method' => "GET", 'header' => "Referer: ". $referer ) ); $context = stream_context_create($opts); echo <<<EOM1
<script src="https://cdn.jsdelivr.net/npm/hls.js@canary"></script>
<audio id="audioimg" controls preload=metadata></audio>
<script>
  var audio = document.getElementById('audioimg');
  var audioSrc = '$url';
EOM1;
if ($token != "") { echo <<<EOM2
    var config = {
        xhrSetup: xhr => {
        //xhr.setRequestHeader("User-Agent",            "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_0_1; Valve Steam GameOverlay/1679680416) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.121 Safari/537.36");
        //xhr.setRequestHeader("paragram",            "no-cache");
        //xhr.setRequestHeader("X-Radiko-App",        "$app");
        //xhr.setRequestHeader("X-Radiko-App-Version","$ver");
        //xhr.setRequestHeader("X-Radiko-User",       "$user");
        //xhr.setRequestHeader("X-Radiko-Device",     "$dev");
        xhr.setRequestHeader("X-Radiko-AuthToken",  "$token");
        //xhr.setRequestHeader("X-Radiko-PartialKey", "$partialkey");
        }
    };
EOM2;
} else { echo <<<EOM3
    var config = {
    };
EOM3;
} echo <<<EOM4
  if (Hls.isSupported()) {
      var hls = new Hls(config);
      hls.loadSource(audioSrc);
      hls.attachMedia(audio);
  } else if (audio.canPlayType('application/vnd.apple.mpegurl')) {
    audio.src = audioSrc;
  }
</script>
EOM4;
} function ht_prtest($val) { msgx('<pre>'); print_r($val); msgx('</pre>'); } function ht_at_test() { global $headless_browser; echo_msg(2,""); echo_msg(2,"atコマンドのテストを行います。"); echo_msg(2,""); $dt = "dt_".date("YmdHis"); $extime = "now+2min"; $atcmd = "echo \"/usr/bin/touch /tmp/$dt\" | /usr/bin/at $extime"; echo "$atcmd <br>"; system($atcmd,$ret); echo "ret : $ret <br>"; return; $job = ht_at_test_sub($extime, $command); echo "job : $job <br>"; } function ht_at_test_sub($extime, $command) { $desc = array( 0 => array("pipe", "r"), 1 => array("pipe", "w"), 2 => array("pipe", "w"), ); $exat = "/usr/bin/at"; $atcmd = $exat." ".$extime; echo "$atcmd <br>"; $proc = proc_open($atcmd, $desc, $pipe); if ($proc === false) { echo "proc_open error <br>"; return false; } fputs($pipe[0], $command); fclose($pipe[0]); $buf = trim(fgets($pipe[2], 4096)); fclose($pipe[2]); fclose($pipe[1]); proc_close($proc); return(preg_replace("/^job\s+(\d+).*$/", "$1", $buf)); } function ht_sftp_test() { echo_msg(2,""); echo_msg(2,"sftpコマンドのテストを行います。"); echo_msg(2,""); $host = "192.168.1.23"; $port = "22"; $user = 'rpi'; $pass = 'rfriends'; $src_file = "/home/rpi/sftp27.txt"; $dst_file = "/home/rpi/sftp23.txt"; $mode = "0644"; $ssh2_connect = ssh2_connect($host, $port); if ($ssh2_connect === false) { echo_msg(2,"ssh2_connect error"); return; } $ret = ssh2_auth_password($ssh2_connect, $user, $pass); if ($ret === false) { echo_msg(2,"ssh2_auth_password error"); return; } $sftp = ssh2_sftp($ssh2_connect); if ($sftp === false) { echo_msg(2,"ssh2_sftp error"); return; } $ret = ssh2_scp_send($ssh2_connect, $src_file ,$dst_file ,$mode); if ($ret === false) { echo_msg(2,"ssh2_scp_send error"); return; } $ret = ssh2_disconnect($ssh2_connect); if ($ret === false) { echo_msg(2,"ssh2_disconnect error"); return; } echo_msg(2,"sftp end"); } function ht_headless_test() { global $headless_browser; global $headless_lightpanda; echo_msg(2,""); echo_msg(2,"headlessブラウザのテストを行います。"); echo_msg(2,""); echo_msg(2,"headless_lightpanda : $headless_lightpanda"); echo_msg(2,"headless_browser : $headless_browser"); echo_msg(2,""); if (rf_headless_check() == 0) { echo_msg(2,"headlessブラウザのSWがOFFなのでテストを中止します。"); } $msg = "urlを入力してください。"; ht_input($msg,0,""); } function ht_headless_test2() { global $headless_browser; global $headless_lightpanda; echo_msg(2,""); echo_msg(2,"headlessブラウザのテスト(NHK)を行います。"); echo_msg(2,""); echo_msg(2,"headless_lightpanda : $headless_lightpanda"); echo_msg(2,"headless_browser : $headless_browser"); echo_msg(2,""); if (rf_headless_check() == 0) { echo_msg(2,"headlessブラウザのSWがOFFなのでテストを中止します。"); } $msg = "urlを入力してください。"; ht_input($msg,0,""); } function ht_rss_test() { echo_msg(2,""); echo_msg(2,"rssの表示を行います。"); echo_msg(2,""); $msg = "rssのurlを入力してください。"; ht_input($msg,0,""); } function ht_pulldown_test() { global $sound_mode; echo_msg(2,""); echo_msg(2,"pulldownのテストを行います。"); echo_msg(2,""); echo "<p>audio card(ALSA)の選択をおこないます。</p>"; echo "<p>&nbsp;</p>"; $cards = rf_alsa_list(); $main_cat = rf_alsa_cat_cards($cards); if ($main_cat == array()) { echo_msg(2,"サウンドカードがみつかりません。"); return false; } $sub_cat = rf_alsa_cat_mixer($cards); if ($sub_cat == array()) { echo_msg(2,"オーディオミキサーがみつかりません。"); return false; } $now_asound = rf_get_alsa(); if ($now_asound !== false) { $card = $now_asound[0]; $mixer = $now_asound[1]; echo_msg(2,"現在、以下が選択されています。"); echo_msg(2,"card  : $card"); echo_msg(2,"mixer : $mixer"); echo_msg(2,""); } $json_main = json_encode($main_cat); $json_sub = json_encode($sub_cat); echo <<<EOF
<form action="menu_ss.html" method="get">
Card :</br>
      <select id="main-cat-sel" name=val style="width:200px">
        <option disabled selected>選択してください</option>
      </select>

<p>&nbsp;</p>

Mixer:</br>
      <select id="sub-cat-sel" name=sel style="width:200px">
        <option disabled selected>選択してください</option>
      </select>
<INPUT type='hidden' name='subno' value='010702'>
<INPUT type='hidden' name='val2'   value='12'>

<p><br><button class='btn_ex' type='submit'>選択</button></p>
</form>    

<script>
rf_pulldown_menu($json_main,$json_sub);

function rf_pulldown_menu(json_main,json_sub){

let main_cat = json_main;
let sub_cat  = json_sub;

//console.log(main_cat);
//console.log(sub_cat);

const maincatsel = document.getElementById('main-cat-sel');
const subcatsel = document.getElementById('sub-cat-sel');

// main
main_cat.forEach(category => {
  const option = document.createElement('option');
  option.textContent = category;

  maincatsel.appendChild(option);    
});

// sub
maincatsel.addEventListener('input', () => {

  // reset sub
  const options = document.querySelectorAll('#sub-cat-sel > option');
  options.forEach(option => {
    option.remove();
  });

  // sub
  //const firstSelect = document.createElement('option');
  //firstSelect.textContent = '選択してください';
  //subcatsel.appendChild(firstSelect);

  // select sub
  sub_cat.forEach(subCategory => {
    if (maincatsel.value == subCategory.category) {
      const option = document.createElement('option');
      option.textContent = subCategory.name;
      
      subcatsel.appendChild(option);
    }
  });
});
}
</script>
EOF;
} function ht_audio_test_s($ex_type,$para,$flg) { global $station_logo_url; global $ex_radiko; global $ex_radiru; global $ex_timefree; global $ex_radiru_vod; global $ex_radiru_gogaku; global $nowarea; global $auth_token; global $ui_mode; global $scrdir; $org = 0; switch($ex_type) { case $ex_radiko: $opt = rfriends_live_radiko($ex_type,$para,$flg); break; case $ex_timefree: $opt = rfriends_live_timefree($ex_type,$para,$flg,$org); break; case $ex_radiru: $opt = rfriends_live_radiru($ex_type,$para,$flg); break; case $ex_radiru_vod: case $ex_radiru_gogaku: $opt = rfriends_live_radiru_vod($ex_type,$para,$flg); break; default: return false; break; } if ($opt === false) return false; if ($ui_mode == 22) { if ($para[9] != ";") { msgx('<p><img src='.$para[9].' id="sndimg"></p>'); } else if($ex_type == $ex_radiru || $ex_type == $ex_radiru_vod) { $ch_cs = callsign2($para[6]); if ($ch_cs != "UNKNOWN") { $img = sprintf($station_logo_url, $ch_cs); msgx('<p><img src='.$img.' id="sndimg"></p>'); } } $tmp = explode(",",$opt); $url = str_replace('"','',$tmp[4]); if ($ex_type == $ex_radiko || $ex_type == $ex_timefree) { $nw = explode(",",$nowarea); $area = $nw[0]; $channel = $para[6]; $auth_token = rfriends_auth_audio($ex_type,$area,$channel); if ($auth_token === false) { echo_msg(2,"auth error"); } ht_exaudio($url,$auth_token,""); } else { ht_exaudio($url,"",""); } exit; } $piddata = rfmenu_play_abort_all(); echo_msg(2,$para[6]); echo_msg(2,$para[7]); echo_msg(2,$para[8]); $nam = "rfriends_exec_live"; $ex = "ex_rfriends"; rfgw_batsh_sub($scrdir, $ex, "14 ".$opt, 1, 1); echo_msg(2, "聴取を開始しました..."); echo_msg(2, "音が出るまで少し時間がかかります"); echo_msg(2, "処理はバックグラウンドで行われます"); return true; } function ht_audio_test() { global $ex_timefree; echo <<<EOM
 <div class="select">
    <input id="file1" type="file" accept=".mp3,.m4a,.aac,.wav,.flac">
    <button onclick="play()" class="btn active">再生</button>
  </div>
EOM;
} function ht_radiko_test() { global $scrdir; global $ex_webradio; global $ex_webradio_cors; global $ex_radiko; $sw = 1; echo_msg(2,""); echo_msg(2,"radikoのテストを行います。"); echo_msg(2,""); if ($sw == 1) { $ex_type = $ex_radiko; $val="20260621051500 20260621053000 00900 0 0 0 TBS イトーとスドーのモノ申し隊! ; https://program-static.cf.radiko.jp/782f8002-5dbc-4385-b2fc-03f77dd2ec86.jpeg NOW 13491586 ; ; ; ; ; ; ;"; $val2 = rfmenu_onair_select($val,$ex_type); if ($val2 === false) { echo_msg(2,"放送されていません。"); } else { ht_live_test($val2,$ex_type); } } else { $ex_type = $ex_webradio_cors; $areaid = 1; $id = '30011'; $para = ht_listenradio_chinfo($areaid,$id); if ($para === false) { return; } $ex_type = "$ex_webradio_cors"; $wdat = put_para($para,$ex_type); ht_wdat_pgm_disp($wdat,$ex_type,1); rfriends_live_test($ex_type,$para,0); } } function rfriends_live_radiko_test($ex_type,$para,$flg) { global $area_code; global $tmpdir; global $premium; global $user_auth; $channel = $para[6]; $mode = rf_premium_mode($ex_type,$area_code,$channel); $authtoken = rfriends_auth_radiko($mode,$area_code,0); if (is_null($authtoken)) { echo_prn(1, "radiko_auth error (プレミアム : $mode)"); return false; } $mode2 = $mode; if ($premium == 2) $mode2 = 0; $hlsurl = get_radiko_streamurlhls($authtoken,$channel,$mode2,0); if ($hlsurl == "") { echo_msg(2, "stream_url not found (not delivered)"); return false; } $opt = base64_encode("$ex_type,$channel,$flg,$authtoken,$hlsurl"); return $opt; } function ht_live_test($wdat,$ex_type) { global $ex_radiko; global $ex_radiru; $para = get_para($wdat, $ex_type); ht_wdat_pgm_disp($wdat,$ex_type,1); rfriends_live_test($ex_type,$para,0); echo_msg(2," 時間により次の番組の可能性があります。"); echo_msg(2,""); } function rfriends_live_test($ex_type,$para,$flg) { global $ui_mode; if ($ui_mode == 2) { if ($para[9] != ";") { msgx('<p><img src='.$para[9].' id="sndimg"></p>'); } else if($ex_type == $ex_radiru || $ex_type == $ex_radiru_vod) { $ch_cs = callsign2($para[6]); if ($ch_cs != "UNKNOWN") { $img = sprintf($station_logo_url, $ch_cs); msgx('<p><img src='.$img.' id="sndimg"></p>'); } } } $ret = rfriends_live_sub_test($ex_type,$para,$flg,1,1); return $ret; } function rfriends_live_sub_test($ex_type,$para,$flg,$auto,$tf7) { global $station_logo_url; global $ex_radiko; global $ex_radiru; global $ex_timefree; global $ex_radiru_vod; global $ex_radiru_gogaku; global $ex_podcast; global $ex_webradio; global $ex_webradio_cors; global $nowarea; global $auth_token; global $ui_mode; global $scrdir; global $tmpdir; global $htmldir; $piddata = rfmenu_play_abort_all(); $files = $htmldir."/temp/playtf_*.m3u8"; foreach (glob($files) as $val ) { unlink($val); } $org = 0; switch($ex_type) { case $ex_radiko: $opt = rfriends_live_radiko_test($ex_type,$para,$flg); break; case $ex_timefree: $opt = rfriends_live_timefree($ex_type,$para,$flg,$org,$tf7); break; case $ex_radiru: $opt = rfriends_live_radiru($ex_type,$para,$flg); break; case $ex_radiru_vod: case $ex_radiru_gogaku: $opt = rfriends_live_radiru_vod($ex_type,$para,$flg); break; case $ex_podcast: $opt = rfriends_live_podcast($ex_type,$para,$flg); break; case $ex_webradio: $opt = rfriends_live_webradio($ex_type,$para,$flg); break; case $ex_webradio_cors: $targetM3u8Url = $para[11]; if ($targetM3u8Url == null) { return false; } $proxyScript = "ht_cors_radiko.php"; $targetOrigin = "https://listenradio.jp"; ht_exaudio_cors2($proxyScript, $targetM3u8Url, $targetOrigin, $token = ""); return true; break; default: $opt = rfriends_live_misc($ex_type,$para,$flg); break; } if ($opt === false) return false; if ($auto == 1 && $ui_mode == 2) { $tmp = explode(",",$opt); $url = str_replace('"','',$tmp[4]); if ($ex_type == $ex_radiko) { $nw = explode(",",$nowarea); $area = $nw[0]; $channel = $para[6]; $auth_token = rfriends_auth_audio($ex_type,$area,$channel); if ($auth_token === false) { echo_msg(2,"auth error"); return false; } $url = rfriends_live_radiko_exaudio($auth_token,$channel); echo_msg(2,"url: $url"); $targetM3u8Url = $url; $proxyScript = "ht_cors_radiko.php"; $targetOrigin = "https://radiko.jp"; ht_exaudio_cors2_test($proxyScript, $targetM3u8Url, $targetOrigin, $auth_token); return true; } else if ($ex_type == $ex_timefree){ $url2 = str_replace($htmldir,"",$url); ht_exaudio($url2,"",""); } else { ht_exaudio($url,"",""); } return true; } if ($auto == 1) { echo_msg(2,$para[6]); echo_msg(2,$para[7]); echo_msg(2,$para[8]); } $nam = "rfriends_exec_live"; $ex = "ex_rfriends"; rfgw_batsh_sub($scrdir, $ex, "14 ".$opt, 1, 1); return true; } function ht_exaudio_cors2_test($proxyScript, $targetM3u8Url, $targetOrigin, $token = "") { echo_msg(2,"proxyScript   : $proxyScript"); echo_msg(2,"targetM3u8Url : $targetM3u8Url"); echo_msg(2,"targetOrigin  : $targetOrigin"); echo_msg(2,"token         : $token"); echo <<<EOF
<audio id="audio" class="audioframe" controls >
</audio>
<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
<script>
const proxyScript = "{$proxyScript}";
const targetM3u8Url = "{$targetM3u8Url}";
const targetOrigin = "{$targetOrigin}";
const authToken = "{$token}"; // ★トークンが空なら空文字、あればradikoトークンが入る

if (Hls.isSupported()) {
    const hls = new Hls({
        xhrSetup: function (xhr, url) {
            // ★多重処理防止。URLにプロキシ名が含まれている場合
            if (url.includes(proxyScript)) {
                // トークンが指定されているのに URL にまだ付与されていない場合だけ処理を続行、それ以外はパス
                if (!authToken || url.includes('authtoken=')) {
                    return;
                }
            }

            let resolvedUrl = url;
            console.log('1. resolvedUrl : %s',resolvedUrl);

            if (url.startsWith(window.location.origin) || !url.startsWith('http')) {
                const urlObj = new URL(url, window.location.origin);
                const pathAndQuery = urlObj.pathname + urlObj.search;

                const baseObj = new URL(targetM3u8Url);
                const baseDir = baseObj.pathname.substring(0, baseObj.pathname.lastIndexOf('/') + 1);
                
                if (pathAndQuery.startsWith('/')) {
                    resolvedUrl = baseObj.origin + baseDir + pathAndQuery.substring(1);
                } else {
                    resolvedUrl = baseObj.origin + baseDir + pathAndQuery;
                }
            }
            console.log('2. resolvedUrl : %s',resolvedUrl);
            if (resolvedUrl.startsWith('http') && !resolvedUrl.startsWith(window.location.origin)) {
                // ★共通化：URLの末尾を生成（トークンがある場合のみ &authtoken= を追加）
                let queryParam = "?url=" + encodeURIComponent(resolvedUrl) + "&org=" + encodeURIComponent(targetOrigin);
                if (authToken) {
                    queryParam += "&authtoken=" + encodeURIComponent(authToken);
                }
                resolvedUrl = proxyScript + queryParam;
            }
            console.log('3. resolvedUrl : %s',resolvedUrl);
            xhr.open('GET', resolvedUrl, true);
        }
    });

    // ★共通化：初回URLの生成（トークンがあれば自動付与）
    let initialUrl = proxyScript + "?url=" + encodeURIComponent(targetM3u8Url) + "&org=" + encodeURIComponent(targetOrigin);
    if (authToken) {
        initialUrl += "&authtoken=" + encodeURIComponent(authToken);
    }
    console.log('4. initialUrl : %s',initialUrl);
    hls.loadSource(initialUrl);
    hls.attachMedia(audio);
            
            hls.on(Hls.Events.MANIFEST_PARSED, function () {
                audio.play().catch(function(error) {
                    console.log("自動再生がブロックされました。");
                });
            });

            hls.on(Hls.Events.ERROR, function (event, data) {
                if (data.fatal) {
                    console.error("致命的なエラーが発生しました:", data);
                }
            });

        } else if (audio.canPlayType('application/vnd.apple.mpegurl')) {
            // ★共通化：iOS用URLの生成（トークンがあれば自動付与）
            let fallbackUrl = proxyScript + "?url=" + encodeURIComponent(targetM3u8Url);
            if (authToken) {
                fallbackUrl += "&authtoken=" + encodeURIComponent(authToken);
            }
            audio.src = fallbackUrl;
            audio.addEventListener('loadedmetadata', function () {
                audio.play();
            });
        } else {
            alert("お使いのブラウザはHLS音声再生に対応していません。");
        }
    </script>
EOF;
} function ht_hlsjs_test() { echo_msg(2,""); echo_msg(2,"音泉のテストを行います。........"); echo_msg(2,""); $url = "https://www.onsen.ag/"; $html = rf_file_get_contents($url); if ($html === false) { echo_msg(2,"error get $url"); return false; } if (preg_match('/([^;]*?)\.title\s*=\s*"(.*?)"[^;]*;/', $html, $matches)) { ht_print_r($matches[0],"0"); ht_print_r($matches[1],"1"); ht_print_r($matches[2],"2"); } else { echo_msg(2,"not found title"); return false; } return; echo_msg(2,""); echo_msg(2,"hlsjsのテストを行います。........"); echo_msg(2,""); $msg = "urlを入力してください。"; ht_input($msg,0,""); } 