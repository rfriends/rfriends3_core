<?php
 function ht_sub_win() { echo_msg(2,""); echo_msg(2,"windows : この機能は現在開発中です。"); } function ht_sub_win_s($val) { echo_msg(2,"windows : $val"); } function ht_sub_win_ss($val,$val2) { echo_msg(2,"windows : $val $val2"); } ?>
