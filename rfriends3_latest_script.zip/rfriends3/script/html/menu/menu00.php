<?php
 $rfname = rfmenu_name(); switch ($sno) { case "s01": $mes = "NOW ON AIR"; ht_subtitle("000101",$mes); rfmenu00(); break; default; break; } 