@echo off
rem -----------------------------------------
rem Rfriends updatestation
rem 
rem 2026/07/19 by mapi
rem -----------------------------------------
echo update station
echo.

cd /d %~dp0
set base=%CD%\

%base%bin\php\php %base%script\updatestation.php
echo done
pause
exit
